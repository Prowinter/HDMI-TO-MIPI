## 文件说明

* MiniDisplay：这是我原版设计电路，硬件已经验证过但是固件代码还没来得及写
* Converter-10.1：和上面的核心板配套的10.1寸屏转接板
* MiniDisplay-ylj2000：这是由[ylj2000](https://github.com/ylj2000)基于我原版硬件方案修改的电路，将转接板改为了排针连接的形式，另外这个方案的固件代码也已经由[ylj2000](https://github.com/ylj2000)实现，目前适配了5.5寸的1080p屏幕
* Converter_5_5：和上面的板子配套的转接板

