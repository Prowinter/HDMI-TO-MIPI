files = ["framebuffer/framebuffer.v", "framebuffer/video_mixer.v", "pll_drp/pll_drp.v", "sysctl/sysctl_regs.v", "sysctl/edid_eeprom.v"];

modules = {"local" : [ "dsi_core", "fmlarb", "hpdmc", "hdmi_common", "hdmi_rx" ]}

