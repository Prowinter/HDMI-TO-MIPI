files = ["dcmspi.v",
"debnce.v",
"DRAM16XN.v",
"hdclrbar.v",
"synchro.v",
"timing.v"];
