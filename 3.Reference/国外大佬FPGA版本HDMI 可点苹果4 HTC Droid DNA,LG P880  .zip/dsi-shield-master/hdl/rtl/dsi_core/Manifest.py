files = ["dphy_lane.v",
         "dphy_serdes.v",
         "dsi_core.v",
         "dsi_packer.v",
         "dsi_packet_assembler.v",
         "dsi_timing_gen.v",
         "dsi_utils.v"]
