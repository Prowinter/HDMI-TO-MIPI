files = ["rev2_top.vhd", 
	 "rev2_top.ucf",
	 "reset_gen.vhd" ]

fetchto = "../../ip_cores"

modules = {
    "local" : ["../../rtl/", "../../ip_cores" ]
    }
